#include <iostream>
#include <list>
#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <vector>
#include <set>
#include <thread>
#include <mutex>
#include <sched.h>
#include "timehelper.h"
#include "threadbarrier.h"
#include "strategy/lockablebase.h"
#include "strategy/mrlockable.h"
#include "mrlock.h"
#include <chrono>


// Program variables
const int NUM_THREADS = 8;
const int NUM_RESOURCES = 64;
const int NUM_ITERATIONS = 100000;
const bool INDEX_LOCKING = true;
const bool DEBUG_ON = false;

// Hash Entry / Node
class HashNode
{
	public:
		int key;
		int value;

		HashNode(int k, int v) {
			key = k;
			value = v;
		}
};

//Hash Table
class Hash 
{ 
	private:
		// No. of buckets
		int BUCKET;

		// Pointer to an array containing buckets
		std::list<HashNode> *table;

	public: 
		// Constructor
		Hash(int bucketSize);

		// Inserts a key into hash table
		void insertItem(int key, int value);

		// Deletes a key from hash table
		void deleteItem(int key);

		// Find a key in the hash table
		bool findItem(int key);

		// Hash function to map key to index
		int hashFunction(int key)
		{
			return (key % BUCKET);
		}

		void displayHash();
}; 

Hash::Hash(int bucketSize)
{ 
	this->BUCKET = bucketSize;
	table = new std::list<HashNode>[BUCKET];
} 

void Hash::insertItem(int key, int value)
{
	// Only insert if key is not found in hash table
	if (!this->findItem(key)) {
		int index = hashFunction(key);
		table[index].push_back(HashNode(key, value));
	}
} 

void Hash::deleteItem(int key) 
{
	// get the hash index of key
	int index = hashFunction(key);

	// find the key in (index)th list
	std::list<HashNode>::iterator i;

	for (i = table[index].begin(); i != table[index].end(); i++)
	{
		HashNode entry = *i;
		if (entry.key == key) {
			table[index].erase(i);
			break;
		}
	}
}

bool Hash::findItem(int key)
{
	// Result of find
	bool foundKey = false;

	// get the hash index of key
	int index = hashFunction(key);

	// find the key in (index)th list
	std::list<HashNode>::iterator i;

	for (i = table[index].begin(); i != table[index].end(); i++)
	{
		HashNode entry = *i;
		if (entry.key == key) {
			foundKey = true;
			break;
		}
	}

	return foundKey;
}

// function to display hash table 
void Hash::displayHash() 
{
	for (int i = 0; i < BUCKET; i++)
	{ 
		std::cout << i; 
		for (HashNode x : table[i]) {
			std::cout << " --> (" << x.key << "," << x.value << ")";
		}
		std::cout << std::endl;
	}
} 

/**
 * Method that generates the operation type to perform (insert, find, delete).
 * The operation distribution can be set by changing the constants.
 */
int operationType()
{
	const double findPercent = 0.2; // 20%
	const double deletePercent = 0.4; // 40%

	double random = (double)rand() / RAND_MAX;
	int operation = 0; // Insert (default)

	if (random < findPercent) { // Find
		operation = 1;
	}
	else if (random < (findPercent + deletePercent)) { // Delete
		operation = 2;
	}

	return operation;
}

void threadRipper(int threadNum, ResourceAllocatorBase* resourceAlloc, int NUM_ITERATIONS, Hash* hashTable)
{
    //Initialize the structure
    //The set of resource ids is ordered so that the resourceIdVec is ordered
    std::set<unsigned> resourceSet;
    std::vector<ResourceAllocatorBase::ResourceIdVec> resourceIdVec;
    resourceIdVec.resize(NUM_ITERATIONS);
    int opType;
    LockableBase* resourceLock;

    for (int i =0; i<NUM_ITERATIONS; i++)
    {
    	resourceSet.clear();
		if(INDEX_LOCKING) {
			resourceSet.insert(hashTable->hashFunction(i));
		}
		else {
			resourceSet.insert(1);
		}
		resourceIdVec[i].assign(resourceSet.begin(), resourceSet.end());
		resourceLock = resourceAlloc->CreateLockable(resourceIdVec[i]);
		resourceLock->Lock();

        opType = operationType();
        if (opType == 0) { // Insert
			hashTable->insertItem(i, threadNum);
        }
        else if (opType == 1) { // Find
			hashTable->findItem(i);
        }
        else if (opType == 2) { // Delete
        	hashTable->deleteItem(i);
        }

        resourceLock->Unlock();

        delete resourceLock;
    }
}

int main()
{


    Hash* hashTable = new Hash(NUM_RESOURCES);

    //Create resource allocator
    ResourceAllocatorBase* resourceAlloc = NULL;
    resourceAlloc = new MRResourceAllocator(NUM_RESOURCES);

    auto start_time = std::chrono::high_resolution_clock::now();

    // Create threads
    std::vector<std::thread> thread(NUM_THREADS);
    for(unsigned i=0; i<NUM_THREADS; i++) {
		thread[i] = std::thread(threadRipper, i, resourceAlloc, NUM_ITERATIONS, hashTable);
    }

    // Join threads
    for(unsigned i=0; i<thread.size(); i++) {
    	thread[i].join();
    }

    auto end_time = std::chrono::high_resolution_clock::now();

    double multithreaded_time = std::chrono::duration_cast<std::chrono::nanoseconds>(end_time - start_time).count();
    multithreaded_time = multithreaded_time * 1e-9;

    // Output for debug
    if(DEBUG_ON) {
    	hashTable->displayHash();
    }

    std::cout << "Number of threads: " << NUM_THREADS << std::endl;
    std::cout << "Number of operations per thread: "<< NUM_ITERATIONS << std::endl;
    std::cout << "Multi-threaded execution time (s): "<< multithreaded_time << std::endl;
    std::cout << "Number of Resources / Buckets: "<< NUM_RESOURCES << std::endl;
    std::cout << "Index Locking: "<< INDEX_LOCKING << std::endl;

    //std::cout<<std::thread::hardware_concurrency()<<std::endl;

    delete resourceAlloc;
    return (0);
}
