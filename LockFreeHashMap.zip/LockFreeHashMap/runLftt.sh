#!/bin/bash

for i in `seq 1 5`;
do
	./a.out >> lfttOutput.csv
done
