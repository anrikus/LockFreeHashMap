#include <iostream>
#include <atomic>
#include <set>
#include <iterator>
#include <list>
#include <cstdio>
#include <thread>
#include <chrono>
#include <vector>
#include <iterator>
#include <iomanip>

#define SetMark(p) (p|Mark)
#define ClearMark(p) (p & ~Mark)
#define IsMarked(p) (p & Mark)
#define FIXED_FLOAT(f) std::fixed<<std::setprecision(2)<<(f)
#define INVALID -1 //effectively ruling out negative values or at-least -1. Need to find a better way.
#define BUCKETS 1000000
#define NUM_THREADS 8
#define TOTAL_ITERATIONS 8000000
#define NUM_KEYS 1000000

using namespace std;

int Mark = 0x1;

enum TxStatus{
    Active,
    Committed,
    Aborted
};

enum OpType{
    op_insert,
    op_delete,
    op_find,
    op_update // as per section 3.2
};

struct Operation{
    OpType type;
    int key;
    int value; // as per section 3.2 // IN ALGORIHM 10 LINE 18
};

struct Desc{
    int size;
    std::atomic <TxStatus> status; // !!!ALERT!!! ADDING TO ACCOMODATE ALGORITHM 3 LINE 10
    Operation* ops; // !!!ALERT!!! MODIFIED
};

struct NodeInfo{
    Desc* desc;
    int opid;
    int value; // !!!ALERT!!! ADDING TO ACCOMODATE ALGORITHM 10's REQUIREMENT
};

struct Node{
    std::atomic <NodeInfo*> info; // !!!ALERT!!! improvised CAS on line 20 of Algorithm 10
    int key;
    int value; //as per section 3.2
};

enum OpReturn{
    success,
    fail,
    retry
};

thread_local std::vector <Desc*> helpStack;

Node* table[BUCKETS];
std::atomic<int> counter[3];

//Supply for descriptor and nodes

Node NodeArray[TOTAL_ITERATIONS*4];
std::atomic<int> NodeArrayPointer(0);

NodeInfo NodeInfoArray[TOTAL_ITERATIONS*4];
std::atomic<int> NodeInfoArrayPointer(0);

Desc DescArray[TOTAL_ITERATIONS];
std::atomic<int> DescArrayPointer(0);

int TransactionArray[TOTAL_ITERATIONS];
std::atomic <int> TransactionArrayPointer(0);

int ValueArray[TOTAL_ITERATIONS*4];
std::atomic<int> ValueArrayPointer(0);

int DO_HASH(int key){
    return(key%BUCKETS);
}

Node* DO_LOCATEPRED(int key){
    int pos = DO_HASH(key);
    return (table[pos]);
}

bool DO_INSERT(Node* n){
    int key = n->key;
    int pos = DO_HASH(key);
    table[pos] = n;
    return(true);
}

bool DO_DELETE(Node* n){
    int key = n->key;
    int pos = DO_HASH(key);
    //delete(table[pos]);
    table[pos] = NULL;
    return(true);
}

//Algorithm 1 -> Algorithm 9

int IsNodePresent(Node* n, int key){
    return ((n != NULL) and (n->key == key));
}


bool IsKeyPresent(NodeInfo* info, Desc* desc){
//	if(info->desc->ops[info->opid] == nullptr) {
//	cout << info->opid << " -> " << info->desc->status.load() << endl;
//	cout << info->opid << ": " << info->desc->ops[info->opid].type << endl; }
    OpType op = info->desc->ops[info->opid].type;
    TxStatus status = info->desc->status.load();
    switch (status)
    {
        case(Active):{
            if (info->desc == desc){
                return (op==op_update or op==op_find or op==op_insert);
            }
            else{
                return (op==op_update or op==op_find or op==op_delete);
            }
            break;
        }

        case (Committed):{
            return (op==op_update or op==op_find or op==op_insert);
            break;
        }

        case(Aborted):{
            return (op==op_update or op==op_find or op==op_delete); // !!!ALERT!!! Improvised, check page 16 
            break;
        }
    }

    return false;
}

bool IsValuePresent (NodeInfo* info){
    Operation op = info->desc->ops[info->opid];
    if (op.type == op_update or op.type == op_find and op.value!= INVALID){
        return(false);
    }
    return(true);
}

//Algorithm 2 -> Algorithm 10

bool ExecuteOps(Desc* desc, int opid); // Declaration

int MapUpdateInfo(Node* n, NodeInfo* info, bool wantkey){  // !!!ALERT!!! improvised
    NodeInfo* oldinfo = n->info.load();
    if(IsMarked(uintptr_t(oldinfo))){ //improvised
        DO_DELETE (n);
        return (retry);
    }

    if(oldinfo->desc != info->desc){
        ExecuteOps(oldinfo->desc, oldinfo->opid+1);
    }
    else{
        if((oldinfo->opid + 1) == (info->opid)){ // !!!ALERT!!! improvised
            return (success);
        }
    }

    bool haskey = IsKeyPresent(oldinfo, info->desc); // !!!ALERT!!! HOPE IT WORKS

    if ((!haskey and wantkey) or (haskey and !wantkey)){
        return (fail);
    }
    
    if (info->desc->status.load() != Active){
        return (fail);
    }

    Operation op = info->desc->ops[info->opid];

    Operation oldOp = oldinfo->desc->ops[oldinfo->opid];

    if (op.type == op_update or op.type == op_find){
        if ((oldOp.value != n->value) && (oldinfo->desc->status.load() == Committed) and IsValuePresent(oldinfo)){ //  improvised !!!ALERT!!!
            n->value = oldOp.value;
        }
    }

    if (n->info.compare_exchange_strong(oldinfo, info)){
        if (op.type == op_find){
            if (oldOp.type == op_update or (oldOp.type == op_find && oldOp.value != INVALID)){
                n->info.load()->desc->ops[n->info.load()->opid].value = oldOp.value; // !!!ALERT!!! improvised
                return (n->info.load()->value);
            }
            else{
                return (n->value);
            }
        }
        else{
            return (success);
        }    
    }
    else{
        return (retry);
    }
}

// ALGORITHM 3 -> ALGORITHM 5


// DECLARATION FOR LATER FUNCTIONS

bool Insert(int key, Desc* desc, int opid);
bool Find (int key, Desc* desc, int opid);
bool Delete (int key, Desc* desc, int opid, Node*& del);
void MarkDelete (std::set<Node*> delnodes, Desc* desc);


bool ExecuteOps (Desc* desc, int opid){
    bool ret = true;
    std::set <Node*> delnodes;
    std::vector<Desc*>::iterator it;
    for (it = helpStack.begin(); it != helpStack.end(); it++){
        if (*it==desc){
            TxStatus a = Active; // TO ACCOMMODATE COMPARE_EXCHANGE_STRONG
            TxStatus ab = Aborted; // TO ACCOMMODATE COMPARE_EXCHANGE_STRONG
            desc->status.compare_exchange_strong(a, ab);
            return(false);
        }
    }

    helpStack.push_back(desc);
    
    while ((desc->status.load() == Active) and ret and (opid < desc->size)) {
        Operation* op = &(desc->ops[opid]);

        if (op->type == op_find){
            ret = Find(op->key, desc, opid);
        }
        else if (op->type == op_insert){
            ret = Insert(op->key, desc, opid);
        }
        else if (op->type == op_delete){
            Node* del;
            ret = Delete(op->key, desc, opid, del);
            delnodes.insert(del);
        }
        opid = opid + 1;
    }
    helpStack.pop_back();

    if (ret==true){
        TxStatus a = Active; // TO ACCOMMODATE COMPARE_EXCHANGE_STRONG
        TxStatus c = Committed; // TO ACCOMMODATE COMPARE_EXCHANGE_STRONG
        if (desc->status.compare_exchange_strong(a, c)){
            MarkDelete(delnodes, desc);
        }
    }
    else{
        TxStatus a = Active; // TO ACCOMMODATE COMPARE_EXCHANGE_STRONG
        TxStatus b = Aborted; // TO ACCOMMODATE COMPARE_EXCHANGE_STRONG
        desc->status.compare_exchange_strong(a, b);
    }

    return ret;
}

bool ExecuteTransaction (Desc* desc){
    helpStack.clear();
    ExecuteOps(desc, 0);
    return(desc->status.load()==Committed);
}

// ALGORITHM 6

bool Insert(int key, Desc* desc, int opid){ // TO ACCOMODATE VALUE FOR NODE
    //NodeInfo* info = new NodeInfo;
    NodeInfo* info = &NodeInfoArray[NodeInfoArrayPointer.fetch_add(1)];
    info->desc = desc;
    info->opid = opid;
    int ret;

    while(true){
        Node* curr = DO_LOCATEPRED(key);
        if (IsNodePresent(curr, key)){
            ret = MapUpdateInfo(curr, info, false);
        }
        else{
            //Node* n = new Node;
            Node* n = &NodeArray[NodeArrayPointer.fetch_add(1)];
            n->key = key;
            n->info.store(info);
            n->value = desc->ops[opid].value; // ASSIGN VALUE FOR HASHMAP FROM DESCRIPTOR -> OPERATIONS ID -> VALUE
            ret = DO_INSERT(n);
        }

        if(ret==success){
            return(true);
        }
        else if(ret==fail){
            return(false);
        }
    }
}

// ALGORITHM 7

bool Delete (int key, Desc* desc, int opid, Node*& del){
    //NodeInfo* info = new NodeInfo;
    NodeInfo* info = &NodeInfoArray[NodeInfoArrayPointer++];
    info->desc = desc;
    info->opid = opid;
    int ret;
    while(true){
        Node* curr = DO_LOCATEPRED (key);
        if(IsNodePresent(curr, key)){
            ret = MapUpdateInfo(curr, info, true);
        }
        else{
            ret = fail;
        }

        if(ret==success){
            del = curr;
            return (true);
        }

        else if (ret==fail){
            del = NULL;
            return(false);
        }
    }
}

void MarkDelete (std::set<Node*> delnodes, Desc* desc){
    std::set<Node*>::iterator del;
    for (del = delnodes.begin(); del!=delnodes.end();  ++del){
        if(*del==NULL){
            continue;
        }
        Node* temp = *del; // TO ACCOMODATE THE QUIRKS OF STD::SET 
        NodeInfo* info = temp->info.load();
        if(info->desc != desc){
            continue;
        }
        if(temp->info.compare_exchange_strong(info, (NodeInfo*)SetMark(uintptr_t(info)))){
            DO_DELETE (*del);
        }
    }
}

bool Find (int key, Desc* desc, int opid){
    //NodeInfo* info = new NodeInfo;
    NodeInfo* info = &NodeInfoArray[NodeInfoArrayPointer.fetch_add(1)];
    info->desc = desc;
    info->opid = opid;
    int ret;
    while(true){
        Node* curr = DO_LOCATEPRED(key);
        if (IsNodePresent(curr, key)){
            ret = MapUpdateInfo(curr, info, true);
        }
        else{
            ret = fail;
        }

        if(ret==success){
            return(true);
        }
        else if(ret==fail){
            return(false);
        }
    } 
}

void threadRipper(int threadNum)
{
    Desc* d;
    for (int i=0; i<(int)(TOTAL_ITERATIONS / NUM_THREADS); i++) {
    	d = &DescArray[DescArrayPointer++];
    	int transSet = TransactionArray[TransactionArrayPointer.fetch_add(1)];
        if(transSet == 0) { // 4 Inserts
        	Operation op_array[4];
        	op_array[0].type = op_insert;
        	op_array[0].key = ValueArray[ValueArrayPointer++];
        	op_array[0].value = threadNum;
        	op_array[1].type = op_insert;
            op_array[1].key = ValueArray[ValueArrayPointer++];
            op_array[1].value = threadNum;
            op_array[2].type = op_insert;
            op_array[2].key = ValueArray[ValueArrayPointer++];
            op_array[2].value = threadNum;
            op_array[3].type = op_insert;
            op_array[3].key = ValueArray[ValueArrayPointer++];
            op_array[3].value = threadNum;
            d->size = 4;
            d->status.store(Active);
            d->ops = op_array;
            counter[0].fetch_add(4);
        }
        else if(transSet == 1) { // 4 Finds
        	Operation op_array[4];
        	op_array[0].type = op_find;
        	op_array[0].key = ValueArray[ValueArrayPointer++];
        	op_array[0].value = threadNum;
        	op_array[1].type = op_find;
        	op_array[1].key = ValueArray[ValueArrayPointer++];
        	op_array[1].value = threadNum;
        	op_array[2].type = op_find;
        	op_array[2].key = ValueArray[ValueArrayPointer++];
        	op_array[2].value = threadNum;
        	op_array[3].type = op_find;
        	op_array[3].key = ValueArray[ValueArrayPointer++];
        	op_array[3].value = threadNum;
            d->size = 4;
            d->status.store(Active);
            d->ops = op_array;
            counter[2].fetch_add(4);
        }
        else { // 2 Deletes, 2 Finds
        	Operation op_array[4];
        	op_array[0].type = op_find;
        	op_array[0].key = ValueArray[ValueArrayPointer++];
        	op_array[0].value = threadNum;
        	op_array[1].type = op_delete;
        	op_array[1].key = ValueArray[ValueArrayPointer++];
        	op_array[1].value = threadNum;
        	op_array[2].type = op_find;
            op_array[2].key = ValueArray[ValueArrayPointer++];
            op_array[2].value = threadNum;
            op_array[3].type = op_delete;
            op_array[3].key = ValueArray[ValueArrayPointer++];
            op_array[3].value = threadNum;
            d->size = 4;
            d->status.store(Active);
            d->ops = op_array;
            counter[1].fetch_add(2);
			counter[2].fetch_add(2);
        }
        ExecuteTransaction(d);
    }
}

/**
 * Method that generates the which transaction set to perform.
 * The transaction set distribution can be set by changing the constants.
 */
int transactionSet()
{
	const double ts2Percent = 0.1; // 40%
	const double ts3Percent = 0.5; // 40%

	double random = (double)rand() / RAND_MAX;
	int transactionSet = 0; // Transaction set 1

	if (random < ts2Percent) { // Transaction set 2
		transactionSet = 1;
	}
	else if (random < (ts2Percent + ts3Percent)) { // Transaction set 3
		transactionSet = 2;
	}

	return transactionSet;
}

void DO_INIT() {
//    for(int i = 0; i<BUCKETS; i++){
//        table[i] = new Node;
//        table[i]->info.store(new NodeInfo);
//    }

    for(int i=0; i<TOTAL_ITERATIONS; i++){
    	for(int j=0; j<4; j++) {
    		ValueArray[i*4+j] = rand() % NUM_KEYS;
    	}
    	TransactionArray[i] = transactionSet();
	}

    for(int i = 0; i<3; i++){
		counter[i].store(0);
	}

    NodeArrayPointer.store(0);
	NodeInfoArrayPointer.store(0);
	DescArrayPointer.store(0);
	TransactionArrayPointer.store(0);
	ValueArrayPointer.store(0);
}

int main(){

    DO_INIT();

    thread threadPool[NUM_THREADS];
    
    auto start_time = chrono::high_resolution_clock::now();
        
    // Create threads
	for(unsigned i=0; i<NUM_THREADS; i++) {
		threadPool[i] = thread(threadRipper, i);
	}

	// Join threads
	for(unsigned i=0; i<NUM_THREADS; i++) {
		threadPool[i].join();
	}

    auto end_time = chrono::high_resolution_clock::now();

    double multithreaded_time = multithreaded_time + chrono::duration_cast<chrono::nanoseconds>(end_time - start_time).count();
    multithreaded_time = multithreaded_time * 1e-9;
    
    int TOTAL_OPERATIONS = TOTAL_ITERATIONS * 4;
	float insertPercent = (float)(counter[0].load()) / (float)(TOTAL_OPERATIONS) * 100.00;
	float deletePercent = (float)(counter[1].load()) / (float)(TOTAL_OPERATIONS) * 100.00;
	float findPercent = (float)(counter[2].load()) / (float)(TOTAL_OPERATIONS) * 100.00;
	cout << "# of Threads,Execution Time (s),# of Operations, # of Buckets,% of Inserts,% of Deletes,% of Finds" << std::endl;
	cout << NUM_THREADS << "," << multithreaded_time << "," << TOTAL_OPERATIONS << "," << BUCKETS << ",";
	cout << FIXED_FLOAT(insertPercent) << "," << FIXED_FLOAT(deletePercent) << "," << FIXED_FLOAT(findPercent);
	cout << endl;

    return(0);
}
