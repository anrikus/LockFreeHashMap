#include <iostream>
#include <list>
#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <vector>
#include <set>
#include <thread>
#include <mutex>
#include <boost/random.hpp>
#include <sched.h>
#include "timehelper.h"
#include "threadbarrier.h"
#include "strategy/lockablebase.h"
#include "strategy/mrlockable.h"
#include "mrlock.h"
#include <chrono>

//Hash Table


class Hash 
{ 
	// No. of buckets 
	int BUCKET;

	// Pointer to an array containing buckets 
	std::list<int> *table; 

	public: 
  	// Constructor
	Hash(int V);  

	// inserts a key into hash table 
	void insertItem(int x); 

	// deletes a key from hash table 
	void deleteItem(int key); 

	// hash function to map values to key 
	int hashFunction(int x)
	{ 
		return (x % BUCKET); 
	} 

	void displayHash(); 
}; 

Hash::Hash(int b) 
{ 
	this->BUCKET = b; 
	table = new std::list<int>[BUCKET]; 
} 

void Hash::insertItem(int key) 
{ 
	int index = hashFunction(key); 
	table[index].push_back(key); 
} 

void Hash::deleteItem(int key) 
{ 
	// get the hash index of key 
	int index = hashFunction(key); 
	
	// find the key in (index)th list 
	std::list <int> :: iterator i; 

	for (i = table[index].begin(); i != table[index].end(); i++) 
	{ 
		if (*i == key) 
			break; 
	} 

	// if key is found in hash table, remove it 
	if (i != table[index].end()) 
		table[index].erase(i); 
} 

// function to display hash table 
void Hash::displayHash() 
{
	for (int i = 0; i < BUCKET; i++)
	{ 
		std::cout << i; 
		for (auto x : table[i]) 
			std::cout << " --> " << x; 
		std::cout << std::endl; 
	} 
} 

void threadRipper(ResourceAllocatorBase* resourceAlloc, int numIteration, Hash* hashTable)
{
    //Initialize the structure
    //The set of resource ids is ordered so that the resourceIdVec is ordered
    std::set<unsigned> resourceSet;
    std::vector<ResourceAllocatorBase::ResourceIdVec> resourceIdVec;
    //All operations performed thrice
    resourceIdVec.resize(numIteration);
    int opType;
    LockableBase* resourceLock;

    for (int i =0; i<numIteration; i++)
    {
        opType = rand();
        if (opType%3==0)
        {
        resourceSet.clear();
        resourceSet.insert(i%10);
        resourceIdVec[i].assign(resourceSet.begin(), resourceSet.end());
        resourceLock = resourceAlloc->CreateLockable(resourceIdVec[i]);
        resourceLock->Lock();
        hashTable->insertItem(i);
        resourceAlloc->UseResource(resourceIdVec[i]);
        resourceLock->Unlock();
        }
        if (opType%3==1)
        {
        resourceSet.clear();
        for (int j=0; j<10; j++)
        {
            resourceSet.insert(j%10);
        }
        resourceIdVec[i].assign(resourceSet.begin(), resourceSet.end());
        resourceLock = resourceAlloc->CreateLockable(resourceIdVec[i]);
        resourceLock->Lock();
        //hashTable->displayHash();
        resourceAlloc->UseResource(resourceIdVec[i]);
        resourceLock->Unlock();
        }
        if (opType%3==2)
        {
        resourceSet.clear();
        resourceSet.insert(i%10);
        resourceIdVec[i].assign(resourceSet.begin(), resourceSet.end());
        resourceLock = resourceAlloc->CreateLockable(resourceIdVec[i]);
        resourceLock->Lock();
        hashTable->deleteItem(i);
        resourceAlloc->UseResource(resourceIdVec[i]);
        resourceLock->Unlock();
        }

        delete resourceLock;
    }


}



int main()
{
    Hash* hashTable = new Hash(10);
    int numResource = 10;
    int numIteration = 1000;

    std::cout<<numIteration<<std::endl;

    //Create resource allocator
    ResourceAllocatorBase* resourceAlloc = NULL;
    resourceAlloc = new MRResourceAllocator(numResource);

    auto start_time = std::chrono::high_resolution_clock::now();

    std::thread w(threadRipper, resourceAlloc, numIteration, hashTable);
    std::thread x(threadRipper, resourceAlloc, numIteration, hashTable);
    std::thread y(threadRipper, resourceAlloc, numIteration, hashTable);
    std::thread z(threadRipper, resourceAlloc, numIteration, hashTable);
    w.join();
    x.join();
    y.join();
    z.join();

    auto end_time = std::chrono::high_resolution_clock::now();

    double multithreaded_time = multithreaded_time + std::chrono::duration_cast<std::chrono::nanoseconds>(end_time - start_time).count();

    multithreaded_time = multithreaded_time * 1e-9;

    hashTable->displayHash();

    std::cout<<"Number of threads: 4 "<<std::endl;
    std::cout<<"Number of operations per thread: "<<numIteration<<std::endl;
    std::cout<<"Multithreaded execution time: "<<multithreaded_time<<std::endl;

    //std::cout<<std::thread::hardware_concurrency()<<std::endl;

    delete resourceAlloc;
    return (0);
}
